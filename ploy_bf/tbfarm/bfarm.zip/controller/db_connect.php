<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "b_farm";

function getDBConnection() {
    global $servername, $username, $password, $dbname;

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;  // Return the connection
    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        return null;  // Return null if connection failed
    }
}

// Usage
$conn = getDBConnection();
if ($conn) {
    // Connection successful
    // Perform database operations here
} else {
    // Handle connection error
}
?>
